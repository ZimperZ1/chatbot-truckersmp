

# <img src="https://habborator.org/archive/icons/medium/go_arrow.gif"> About:


> ![version](https://img.shields.io/badge/production-2.0.0-green?logo=appveyor&style=flat-square) [![unstable](https://img.shields.io/badge/stability-stable-green?logo=appveyor&style=flat-square)](http://github.com/badges/stability-badges)

> Only for Arcturus Morningstar.

> Project is stopped since Feb 2020. Raizer deleted his Discord and Server, dont trust anyone anyone who act like Raizer, Raizer isn't active at discord anymore. Thanks for all the support and remember, Cosmic is made with love <3

# <img src="https://raw.githubusercontent.com/Wulles/eyethatseeseverything/master/pwrup_pins.gif"> Installation


<a href="https://github.com/devraizer/Cosmic/wiki/Installation---Debian-9,-Morningstar-Arcturus-&-Catalogue---Cosmic">Installation Debian 9, Morningstar Arcturus & Catalogue Cosmic</a>

<a href="https://github.com/devraizer/Cosmic/wiki/Installation---Windows,-Morningstar-Arcturus-&-Catalogue---Cosmic">Windows, Morningstar Arcturus & Catalogue Cosmic</a>

### Clone

- Clone this repo to your local machine using `https://github.com/devraizer/Cosmic.git`

