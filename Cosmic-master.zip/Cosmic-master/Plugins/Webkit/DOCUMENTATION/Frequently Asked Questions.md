## Failed to enable plugin:
-> Invalid request, please update the plugin:

		Update your plugin.
		
-> Your hotel URL isn't valid, check your config.ini

		Update "hh.hotel_url" in your config.ini to your correct URL
		If you believe that your hotel URL is correct, and you still get this message it means that
		the website at the hotel URL isn't a hotel. Point it to your hotel and then try it again.
		
-> The Hackerman.tech database is unavailable

		This means that the Hackerman servers are unavailable, nothing to worry about as plugins should
		load fine.
		
-> Your username/email do not match. Check your config.ini
	
		Please update your username and email in your config.ini - this is used for communication between us
		and you

## Update available 

-> Update for plugin x is available:

		Update the plugin @ hackerman.tech or if you have auto update enabled, you can find the updated file
		in your update directory.


## Plugin Disabled:

-> If you receive a message containing "disabled due to a possible vulnerability":

		Update your plugin as soon as possible, this means that this version of this plugin contains
		a bug or feature that can be considered malicious. We are not responsable if you do not
		update a plugin when a new version comes out, but we try to help you as much as possible, and
		that's why you get this message! ;)
		
-> If you receive a message containing "is disabled because it's outdated":
		
		Update your plugin! You are way too many versions behind and you really should update your
		plugin. Outdated plugins have less features and more bugs. 
		
		
-> If you receive a message containing "is disabled due to a breachment of the terms of service":

		If you receive this it means that you have breached the Arcturus Morningstar terms of service
		or license, the Hackerman terms of service or guidelines or that your hotel is considered an unsafe
		environnement. This is a message you will only see when you do really bad things. Please contact us
		in the Krews Discord to help figure this out, we can figure this out together.