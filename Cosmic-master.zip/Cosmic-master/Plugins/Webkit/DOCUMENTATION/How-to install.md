Thank you for downloading this plugin.

## HOW TO INSTALL?
Move everything from the installation files directory to the appropriate directory and restart your emulator.
SQL's will be automatically created if needed

If applicable:
  Add the external-flash-texts.txt's content to your own external flash texts and clear your cache.
  Move habbopages to the correct directory 

Support is provided on the download page under 'support'.
