Thank you for downloading my plugin, here is a super scary document to explain to you what you shouldn't do.

-> Claim the emulator as your own 
	The emulator wasn't made by you, it's a community project. You must credit the developers and contributors
	of the emulators correctly. Failing to credit the emulator developers, contributors and other correctly can
	lead into having your access to hackerman.tech or any hackerman plugin for an undertermined time.

-> Claim any plugin as your own
	These plugins have not be made by you, so don't claim it as your own.

-> Breachment of the Arcturus Morningstar license or terms of service:
	In case you do not respect the license of Morningstar or breach their terms of service 
	your access to any hackerman.tech or hackerman plugin may be disabled for an undetermined time.
	
-> Unsafe Hotels:
	> If a hotel is getting compromised or was once compromised it can be considered an unsafe hotels
	> If a hotel sells or gives content that contains personal data to a 3rd party with the exception
	of an official Arcturus Morningstar can lead your hotel into be considered unsafe 
	> If a hotel uses, sells, shares, with data from a user without their permission can lead into being
	considered an unsafe hotel.
	
	If your hotel is considered unsafe your access to hackerman.tech or any hackerman plugin
	may be disabled for an undertermined time.
	
This sounds scary, but as long as you do your best to protect your players and if you are respectful to
the Arcturus Morningstar community, contributors and team you have nothing to worry about. In case your
access is disabled you can contact Hackerman#3080 in the Krews Discord (https://discord.gg/XBMYFM8) or
you can send me a private message on the hackerman.tech forums.